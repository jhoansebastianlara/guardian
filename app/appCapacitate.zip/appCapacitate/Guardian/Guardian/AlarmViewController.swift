//
//  AlarmViewController.swift
//  Guardian
//
//  Created by andres felipe vidal lopez on 18/04/15.
//  Copyright (c) 2015 MobiGeek. All rights reserved.
//

import UIKit

class AlarmViewController: UIViewController {
    // funcion para llamar al usuario
    @IBAction func CallToProtector(sender: UIButton) {
        let alert = UIAlertView(title: "Alerta", message: "Se le ha notificado al Protector por favor Aguarde", delegate: nil, cancelButtonTitle: "Cerrar")
        alert.show();
    }
}
