//
//  PanicVewController.swift
//  Guardian
//
//  Created by andres felipe vidal lopez on 18/04/15.
//  Copyright (c) 2015 MobiGeek. All rights reserved.
//

import UIKit

class PanicViewController: UIViewController {
    
    @IBAction func PanicModeOn(sender: UIButton) {
        let alert = UIAlertView(title: "Modo Panico Activado", message: "Se procedera a bloquear el dispositivo por su seguridad, Su guardian ha sido notificado", delegate: nil, cancelButtonTitle: "Bloquear")
        alert.show()
    }
}