//
//  MapViewController.swift
//  Guardian
//
//  Created by andres felipe vidal lopez on 18/04/15.
//  Copyright (c) 2015 MobiGeek. All rights reserved.
//

import UIKit
import MapKit
// clase encargada de controlar el map
class MapViewControllers: UIViewController, MKMapViewDelegate {
    // elemento de tipo map view
    weak var mapView: MKMapView?
    // variable de locacion
    var locationManager: CLLocationManager?
    // contador
    var pos: Int?
    
    // funcion de cara del did
    override func viewDidLoad() {
        super.viewDidLoad()
        // se inicializa el obj de tipo map
        mapView = MKMapView(frame: view.frame)
        // se agrega un delegado al mapView
        mapView?.delegate = self
        // se genera la ubicacion del usuario
        mapView?.showsUserLocation = true
        // se adiciona a la lista
        view.addSubview(mapView!)
        // se inicializa para que solo ingrese un ping
        pos = 0
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        locationManager = CLLocationManager()
        locationManager?.requestAlwaysAuthorization()
    }
    // suncion que mantiene pendiente de la posicion del susuario
    func mapView(mapView: MKMapView!, didUpdateUserLocation userLocation: MKUserLocation!) {
        let region = MKCoordinateRegionMakeWithDistance(userLocation.coordinate, 1000, 1000)
        mapView.setRegion(region, animated: true)
        if pos == 0 {
            addPinToMap()
            pos = 1
        }
        
    }
    // funcion para reconocer que ping se toco
    func mapView(mapView: MKMapView!, didSelectAnnotationView view: MKAnnotationView!) {

        let alert = UIAlertView(title: "Posicion Del Usuario", message: "El Protegido Andres Se encuentra en la Casa", delegate: nil, cancelButtonTitle: "Ok")
        alert.show()
        
    }
    
    
    // funcion para cambiar el color de un pin
    func mapView(mapView: MKMapView!, viewForAnnotation annotation: MKAnnotation!) -> MKAnnotationView! {
        if annotation.isKindOfClass(MKUserLocation.classForCoder()) {
            return nil
        }
        
        let pin = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "PinVioleta")
        pin.pinColor = MKPinAnnotationColor.Purple
        return  pin
    }
    
    func addPinToMap(){
        let pin = MKPointAnnotation()
        pin.subtitle = "ping 1"
        var latitude = mapView!.userLocation.coordinate.latitude + 0.00050
        var longitude = mapView!.userLocation.coordinate.longitude - 0.00001
        pin.coordinate.latitude = latitude
        pin.coordinate.longitude = longitude
        mapView?.addAnnotation(pin)
    }
}
