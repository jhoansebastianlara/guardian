//
//  AddPlaceViewController.swift
//  Guardian
//
//  Created by andres felipe vidal lopez on 18/04/15.
//  Copyright (c) 2015 MobiGeek. All rights reserved.
//

import UIKit

class AddPlaceViewController: UIViewController {
    
}

