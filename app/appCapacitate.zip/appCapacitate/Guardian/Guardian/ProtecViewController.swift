//
//  ProtecViewController.swift
//  Guardian
//
//  Created by andres felipe vidal lopez jhoan sebastian lara on 17/04/15.
//  Copyright (c) 2015 MobiGeek. All rights reserved.
//

// librerias de UI
import UIKit

// clase protecto controller de la super clase UIViewController
class ProtecViewController: UIViewController, AddProtecViewControllerDelegate, UITableViewDataSource {
    
    @IBOutlet weak var TableProtect: UITableView!
    
    // arreglos que almacenan la lista de colores , nombres y relaciones
    
    var names: [String]?
    var relations: [String]?
    var colors: [UIColor]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        println("hola mundo este es el controlador principal")
        names = Array()
        relations = Array()
        colors = Array()
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let identifier = segue.identifier
        
        if identifier == "AddDelegate" {
            let addProtecViewController = segue.destinationViewController as AddProtecViewController
            addProtecViewController.delegate = self
        }
    }
    
    func createProtec(name: String, relation: String, color: UIColor) {
        println("name: \(name) relation: \(relation) color: \(color)")
        
        names?.append(name)
        relations?.append(relation)
        colors?.append(color)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names!.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCellWithIdentifier("CellId") as? UITableViewCell
        
        if cell == nil {
           cell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "CellId")
        }
        cell?.backgroundColor = colors![indexPath.row]
        cell?.textLabel?.text = "\(names![indexPath.row]) : \(relations![indexPath.row])"
        
        return cell!
    }
}