//
//  AddProtecViewController.swift
//  Guardian
//
//  Created by andres felipe vidal lopez jhoan sebastian lara on 17/04/15.
//  Copyright (c) 2015 MobiGeek. All rights reserved.
//

import UIKit

@objc protocol AddProtecViewControllerDelegate {
    func createProtec (name: String, relation: String, color: UIColor)
}

class AddProtecViewController: UIViewController, UITextFieldDelegate {
    
    weak var delegate: AddProtecViewControllerDelegate?
    
    weak var selectedBtnColor: UIButton?
    
    // campo del nombre del protegido
    @IBOutlet weak var nameTextField: UITextField!
    // campo del parentesco con el protegido
    @IBOutlet weak var relationTextField: UITextField!
    
    // metodo para seleccionar el protegido
    @IBAction func selectColor(sender: UIButton) {
        // se verifica que el boton este seleccionado
        if selectedBtnColor? != nil {
            selectedBtnColor?.layer.borderColor = nil
            selectedBtnColor?.layer.borderWidth = 0.0
        }
        
        sender.layer.borderColor = UIColor.blackColor().CGColor
        sender.layer.borderWidth = 2.0
        
        // se guarda el boton al que se le este dando click
        selectedBtnColor = sender
        
    }
    // funcion para guardar un protegido
    @IBAction func saveRelation(sender: UIBarButtonItem) {
        let name = nameTextField.text
        let relation = relationTextField.text
        let color = UIColor( CGColor: selectedBtnColor?.layer.backgroundColor)
        
        // se verifica que el nombre y la relacion se ingresen correctamente
        if name.isEmpty || relation.isEmpty {
            let alert = UIAlertView(title: "Alerta!", message: "Ingresa un nombre y un parentesco", delegate: nil, cancelButtonTitle: "Ok")
            alert.show()
        } else {
            delegate?.createProtec(name, relation: relation, color: color)
            // regresa la vista a el control anterior
            navigationController?.popViewControllerAnimated(true)
        }
    }
    
    // funciones del delegado del teclado
    func textFieldDidEndEditing(textField: UITextField) {
        view.endEditing(true)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        view.endEditing(true)
        return true
    }
}
